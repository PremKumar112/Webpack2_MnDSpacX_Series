There are 4 core concepts:

Entry Point: Where Should Webpack start looking for Dependency
Output: Where Should it store bundle/bundles

Module Loaders like Babel
and Plugins:

So the way Webpack would traverse this is:

Entry Point --> Module Loaders --> Plugins -- > Output